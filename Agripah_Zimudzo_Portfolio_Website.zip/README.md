# Agripah Zimudzo — Professional Portfolio

This is a mobile-friendly, single-page personal portfolio for international Sales & Marketing applications.

## Files
- `index.html` — complete website

## Publish
The easiest free option is GitHub Pages. Create a repository, upload `index.html`, then enable Pages from the repository settings.
